<?php include("template/cabecera2.php"); ?>

<?php 
include("administrador/config/bd.php");
$sentenciaSQL=$conexion->prepare("SELECT * FROM vino");
$sentenciaSQL->execute();
$listaproductos=$sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);
?>

<?php foreach($listaproductos as $vino){ ?>
<div class="col-md-2">
    <div class="card">
    <img class="card-img-top" src="./img/<?php echo $vino['imagen']; ?>" alt="">
        <div class="card-body">
        <h5 class="card-title"><?php echo $vino['nombre']; ?></h5>
        <h6 class="card-title"><?php echo $vino['precio']; ?>€</h6>
            <div class="d-grid gap3-3 col-6 mx-auto">
                <button class="btn btn-primary" role="button"> Comprar </a>
            </div>
        </div>
    </div>
</div>
<?php }?>

<?php include("template/pie.php"); ?>
