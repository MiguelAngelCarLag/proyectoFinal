<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
</head>
<body>
<div class="container">
            <div class="row">
    
    <nav class="navbar navbar-expand lg navbar-dark bg-primary">
            
            <ul class="nav navbar-nav">
               
                
                <li class="nav-item">
                    <a class="btn btn-warning" href="../img/Miguel.jpg"><strong>Proyecto fin de Grado de Miguel Angel Carmona Lago: </strong></a>
                </li>
                <li class="nav-item">
                    <a class="btn btn-success" href="./administrador/"><strong>Administrador del sitio</strong></a>
                </li>
            </ul>
    
    </nav>
      


</body>
</html>