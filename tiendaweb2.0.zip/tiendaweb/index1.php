<?php include("template/cabecera2.php"); ?>

<h1><strong><center><font face="Comic Sans MS">Licores Carmona</font></center></strong></h1>

<div class="album py-5 bg-body-tertiary">
    <div class="container">

      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
             
      <div class="col">
          <div class="card shadow-sm">
            <img src="img/cervecita.jpg" class="d-block w-100">
            <div class="card-body">
              <h3 class="card-text">Cerveza</h3>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                <a class="btn btn-sm btn-outline-success" href="productos1.php">Entrar</a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
            <img src="img/ginebra.jpg" class="d-block w-100">
            <div class="card-body">
              <h3 class="card-text">Ginebra</h3>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                <a class="btn btn-sm btn-outline-success" href="/tiendaweb/productos2.php" >Entrar</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="col">
          <div class="card shadow-sm">
            <img src="img/ron.jpg" class="d-block w-100">
            <div class="card-body">
              <h3 class="card-text">Ron</h3>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                <a class="btn btn-sm btn-outline-success" href="/tiendaweb/productos3.php" >Entrar</a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
            <img src="img/vino.jpg" class="d-block w-100">
            <div class="card-body">
              <h3 class="card-text">Vino</h3>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                <a class="btn btn-sm btn-outline-success" href="/tiendaweb/productos4.php" >Entrar</a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
            <img src="img/vodka.jpg" class="d-block w-100">
            <div class="card-body">
              <h3 class="card-text">Vodka</h3>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                <a class="btn btn-sm btn-outline-success" href="/tiendaweb/productos5.php" >Entrar</a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
            <img src="img/whisky.jpeg" class="d-block w-100">
            <div class="card-body">
              <h3 class="card-text">Whisky</h3>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                <a class="btn btn-sm btn-outline-success" href="/tiendaweb/productos6.php" >Entrar</a>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
  <?php include("template/pie.php"); ?>