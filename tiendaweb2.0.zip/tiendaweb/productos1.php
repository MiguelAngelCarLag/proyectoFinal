<?php include("template/cabecera2.php"); ?>
<?php include 'administrador/config.php'; ?>
<?php include'carrito.php' ?>
<?php 
include("administrador/config/bd.php");
$sentenciaSQL=$conexion->prepare("SELECT * FROM cerveza");
$sentenciaSQL->execute();
$listaproductos=$sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);
?>

<?php foreach($listaproductos as $cerveza){ ?>
    <div class="col-md-2">
        <div class="card">
            <img class="card-img-top" src="./img/<?php echo $cerveza['imagen']; ?>" alt="">
            <div class="card-body">
                <h4 class="card-title"><?php echo $cerveza['nombre']; ?></h4>
                <h4 class="card-title"><?php echo $cerveza['precio']; ?>€</h4>
                <div class="d-grid gap3-3 col-6 mx-auto">
                    <button class="btn btn-primary" role="button"> Comprar </a>
                </div>
            </div>
        </div>
    </div>
<?php }?>
        
<?php include("template/pie.php"); ?>