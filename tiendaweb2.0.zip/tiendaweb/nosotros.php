<?php include("template/cabecera2.php"); ?>
<h1><strong>Bienvenido a Licores Carmona</strong></h1> 
<h4><p>Es una tienda online de venta de bebidas esperituales</p>

<p></p>
</h4>
<div class="col">
    <div align="center">
    <img src="img/carmonal.png" width="250" alt="600">
    </div>
	<br><br>
</div>

<h7>
<h3><u>Formulario de registro en nuestra tienda:</u></h3> 
<br>

<form action="mailto:miguelangelcarmona99@gmail.com.com" method="post" enctype="text/plain">
Nombre <input type="text" name="nombre" size="50" maxlength="100">

Email    <input type="text" name="email" size="50" maxlength="100">
<br><br>
Población <input type="text" name="poblacion" size="20" maxlength="60">
<br>
<br>
<input type="checkbox" name="recibir_info" checked> Deseo recibir notificaciones de ofertas y promociones.
<br>
<br>
<input type="submit" value="Enviar formulario">
<br>


</form>
</h7>

<?php include("template/pie.php"); ?>