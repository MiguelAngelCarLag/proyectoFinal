<?php include("template/cabecera2.php"); ?>

<img 
src="img/Miguel.jpg" 
width="200"
height="700"
alt="">

<?php include("template/pie.php"); ?>