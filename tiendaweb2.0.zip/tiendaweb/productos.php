<?php include'template/cabecera2.php'?>
<?php include 'administrador/config.php'; ?>
<?php include'carrito.php'  ?>
<?php 
include("administrador/config/bd.php");
$sentenciaSQL=$conexion->prepare("SELECT * FROM cerveza");
$sentenciaSQL->execute();
$listaproductos=$sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);
?>

<?php foreach($listaproductos as $cerveza){ ?>
    <div class="col-md-2">
        <div class="card">
            <img class="card-img-top" src="./img/<?php echo $cerveza['imagen']; ?>" alt="">
            <div class="card-body">
                <h5 class="card-title"><?php echo $cerveza['nombre']; ?></h5>
                <h6 class="card-title"><?php echo $cerveza['precio']; ?>€</h6> 
                
                <form action="" method="post">

                        <input type="text" name="id" id="id" value="<?php echo openssl_encrypt($producto['ID'],COD,KEY);?>">
                        <input type="text" name="nombre" id="nombre" value="<?php echo openssl_encrypt($producto['nombre'],COD,KEY);?>">
                        <input type="text" name="precio" id="precio" value="<?php echo openssl_encrypt($producto['precio'],COD,KEY);?>">
                        <input type="text" name="cantidad" id="cantidad" value="<?php echo openssl_encrypt(1,COD,KEY); ?>">
                
                <div class="d-grid gap3-3 col-6 mx-auto">
                    <form action="" method="post">

                    <input type="text" name="id" id="id" value="<?php echo openssl_encrypt($producto['ID'],COD,KEY); ?>">
                    <input type="text" name="nombre" id="nombre" value="<?php echo openssl_encrypt($producto['nombre'],COD,KEY); ?>">
                    <input type="text" name="precio" id="precio" value="<?php echo openssl_encrypt($producto['precio'],COD,KEY); ?>">
                    <input type="text" name="cantidad" id="cantidad" value="<?php echo openssl_encrypt(1,COD,KEY); ?>">

                    <button 
                        class="btn btn-primary"
                        name="btnAccion" 
                        value="Agregar" 
                        type="submit">
                        Comprar
                    </button> 

                    </form>
                    <button 
                        class="btn btn-primary"
                        name="btnAccion" 
                        value="Agregar" 
                        type="submit">
                        Comprar
                    </button>
                </div>
            </div>
        </div>
    </div>
<?php }?>
        
<?php include("template/pie.php"); ?>

