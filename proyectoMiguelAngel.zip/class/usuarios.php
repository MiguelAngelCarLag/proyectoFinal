<?php

class Usuario{
    // Connection
    private $conn;

    // Table
    private $db_table = "usuarios";

    // Columns
    public $id;
    public $nombre;
    public $apellidos;
    public $usuario;
    public $contrasena;
    public $email;

    // DB Connection
    public function __construct($db) {
        $this->conn = $db;
    }

    // Get all
    public function getUser() {
        $sqlQuery = "SELECT * FROM " . $this->db_table . "";
        $stmt = $this->conn->prepare($sqlQuery);
        $stmt->execute();
        return $stmt;
    }
     // Delete product
     public function deleteUser() {
        $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE id = ?";
        $stmt = $this->conn->prepare($sqlQuery);
        $stmt->bindParam(1, $this->id);
        
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }
    public function createUser() {
        $sqlQuery = "INSERT INTO " . $this->db_table . " SET 
            nombre = :nombre, 
            apellidos = :apellidos, 
            usuario = :usuario, 
            contrasena = :contrasena, 
            email = :email 
            ";
        $stmt = $this->conn->prepare($sqlQuery);

        // Sanitize
        $this->nombre = htmlspecialchars(strip_tags($this->nombre));
        $this->apellidos = htmlspecialchars(strip_tags($this->apellidos));
        $this->usuario = htmlspecialchars(strip_tags($this->usuario));
        $this->contrasena = htmlspecialchars(strip_tags($this->contrasena));
        $this->email = htmlspecialchars(strip_tags($this->email));

        // Bind data
        $stmt->bindParam(":nombre", $this->nombre);
        $stmt->bindParam(":apellidos", $this->apellidos);
        $stmt->bindParam(":usuario", $this->usuario);
        $stmt->bindParam(":contrasena", $this->contrasena);
        $stmt->bindParam(":email", $this->email);

        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }
    public function updateUser() {
        $sqlQuery = "UPDATE " . $this->db_table . " SET 
            nombre = :nombre, 
            apellidos = :apellidos, 
            usuario = :usuario, 
            contrasena = :contrasena, 
            email = :email 
                WHERE 
            id = :id
            ";
        $stmt = $this->conn->prepare($sqlQuery);

        // Sanitize
        $this->nombre = htmlspecialchars(strip_tags($this->nombre));
        $this->apellidos = htmlspecialchars(strip_tags($this->apellidos));
        $this->usuario = htmlspecialchars(strip_tags($this->usuario));
        $this->contrasena = htmlspecialchars(strip_tags($this->contrasena));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->id = htmlspecialchars(strip_tags($this->id));

        // Bind data
        $stmt->bindParam(":nombre", $this->nombre);
        $stmt->bindParam(":apellidos", $this->apellidos);
        $stmt->bindParam(":usuario", $this->usuario);
        $stmt->bindParam(":contrasena", $this->contrasena);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":id", $this->id);

        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }
     
}
?>