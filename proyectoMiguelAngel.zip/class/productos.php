<?php

    class Producto {
        // Connection
        private $conn;

        // Table
        private $db_table = "productos";

        // Columns
        public $id;
        public $nombre_producto;
        public $descripcion;
        public $codigo_producto;
        public $imagen;
        public $precio;

        // DB Connection
        public function __construct($db) {
            $this->conn = $db;
        }

        // Get all
        public function getProduct() {
            $sqlQuery = "SELECT * FROM " . $this->db_table . "";
            $stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }

        // Get product
        public function getSingleProduct() {
            $sqlQuery = "SELECT * FROM " . $this->db_table . "
                        WHERE id = ? 
                        LIMIT 0,1";
            $stmt = $this->conn->prepare($sqlQuery);
            $stmt->bindParam(1, $this->id);
            $stmt->execute();
            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);

            $this->nombre_producto = $dataRow['nombre_producto'];
            $this->descripcion = $dataRow['descripcion'];
            $this->codigo_producto = $dataRow['codigo_producto'];
            $this->imagen = $dataRow['imagen'];
            $this->precio = $dataRow['precio'];

        }

        // Create
        public function createProduct() {
            $sqlQuery = "INSERT INTO " . $this->db_table . " SET 
                nombre_producto = :nombre_producto, 
                descripcion = :descripcion, 
                codigo_producto = :codigo_producto, 
                imagen = :imagen, 
                precio = :precio 
                ";
            $stmt = $this->conn->prepare($sqlQuery);

            // Sanitize
            $this->nombre_producto = htmlspecialchars(strip_tags($this->nombre_producto));
            $this->descripcion = htmlspecialchars(strip_tags($this->descripcion));
            $this->codigo_producto = htmlspecialchars(strip_tags($this->codigo_producto));
            $this->imagen = htmlspecialchars(strip_tags($this->imagen));
            $this->precio = htmlspecialchars(strip_tags($this->precio));

            // Bind data
            $stmt->bindParam(":nombre_producto", $this->nombre_producto);
            $stmt->bindParam(":descripcion", $this->descripcion);
            $stmt->bindParam(":codigo_producto", $this->codigo_producto);
            $stmt->bindParam(":imagen", $this->imagen);
            $stmt->bindParam(":precio", $this->precio);

            if ($stmt->execute()) {
                return true;
            } else {
                return false;
            }
        }

        // Update
        public function updateProduct() {
            $sqlQuery = "UPDATE " . $this->db_table . " SET 
                nombre_producto = :nombre_producto, 
                descripcion = :descripcion, 
                codigo_producto = :codigo_producto, 
                imagen = :imagen, 
                precio = :precio 
                    WHERE 
                id = :id
                ";
            $stmt = $this->conn->prepare($sqlQuery);

            // Sanitize
            $this->nombre_producto = htmlspecialchars(strip_tags($this->nombre_producto));
            $this->descripcion = htmlspecialchars(strip_tags($this->descripcion));
            $this->codigo_producto = htmlspecialchars(strip_tags($this->codigo_producto));
            $this->imagen = htmlspecialchars(strip_tags($this->imagen));
            $this->precio = htmlspecialchars(strip_tags($this->precio));
            $this->id = htmlspecialchars(strip_tags($this->id));

            // Bind data
            $stmt->bindParam(":nombre_producto", $this->nombre_producto);
            $stmt->bindParam(":descripcion", $this->descripcion);
            $stmt->bindParam(":codigo_producto", $this->codigo_producto);
            $stmt->bindParam(":imagen", $this->imagen);
            $stmt->bindParam(":precio", $this->precio);
            $stmt->bindParam(":id", $this->id);

            if ($stmt->execute()) {
                return true;
            } else {
                return false;
            }
        }

        // Delete product
        public function deleteProduct() {
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE id = ?";
            $stmt = $this->conn->prepare($sqlQuery);
            $stmt->bindParam(1, $this->id);
            
            if ($stmt->execute()) {
                return true;
            } else {
                return false;
            }
        }
    }
?>