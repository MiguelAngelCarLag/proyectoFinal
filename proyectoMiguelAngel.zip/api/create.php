<?php
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application/json; charset=UTF-8');
    header('Access-Control-Allow-Methods: POST');
    header('Access-Control-Max-Age: 3600');
    header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

    include_once('../config/database.php');
    include_once('../class/productos.php');

    $database = new Database();
    $db = $database->getConnection();

    $item = new Producto($db);

    $item->nombre_producto = $_POST['nombre_producto'];
    $item->descripcion = $_POST['descripcion'];
    $item->codigo_producto = $_POST['codigo_producto'];
    $item->imagen = $_POST['imagen'];
    $item->precio = $_POST['precio'];

    if ($item->createProduct()) {
        echo json_encode("Producto creado correctamente");
    } else {
        echo json_encode("No se ha podido crear el producto");
    }
    


?>