<?php
include_once('../config/database.php');
    include_once('../class/usuarios.php');

    $database = new Database();
    $db = $database->getConnection();

    $item = new Usuario($db);

    $stmt = $item->getUser();
    $itemCount = $stmt->rowCount();
    
    if ($itemCount > 0) {
        $userArr = array();
        $userArr['body'] = array();
        $userArr['itemCount'] = $itemCount;

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            $e = array(
                "id" => $id,
                "nombre" => $nombre,
                "apellidos" => $apellidos,
                "usuario" => $usuario,
                "contrasena" => $contrasena,
                "email" => $email
            );

            array_push($userArr["body"], $e);
        }
        echo json_encode(($userArr));
    } else {
        http_response_code(404);
        echo json_encode(array(
            "message" => "No record found"
        ));
    }
?>