<?php
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application/json; charset=UTF-8');
    header('Access-Control-Allow-Methods: POST');
    header('Access-Control-Max-Age: 3600');
    header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

    include_once('../config/database.php');
    include_once('../class/usuarios.php');

    $database = new Database();
    $db = $database->getConnection();

    $item = new Usuario($db);

    $item->nombre = $_POST['nombre'];
    $item->apellidos = $_POST['apellidos'];
    $item->usuario = $_POST['usuario'];
    $item->contrasena = $_POST['contrasena'];
    $item->email = $_POST['email'];

    if ($item->createUser()) {
        echo json_encode("Usuario creado correctamente");
    } else {
        echo json_encode("No se ha podido crear el usuario");
    }
    


?>