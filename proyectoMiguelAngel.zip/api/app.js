$('#formulario').submit(function(e){
    const postData = {
         nombre: $('#iNombre').val(),
         apellidos: $('#iApellido').val(),
         usuario: $('#iUsuario').val(),
         passwd: $('#iPassword').val(),
         email: $('#iEmail').val(),
    };
    $.post('addUser.php', postData, function(response){
     fetchUser();

         $('#formulario').trigger('reset');
    });
    e.preventDefault();
    
}) 
