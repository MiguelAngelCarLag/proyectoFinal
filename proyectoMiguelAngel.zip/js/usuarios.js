/* Carga */
$(document).ready( () => {

fetchUser();




})

function fetchUser(){                         //esta función me permite mostrar todos los usuarios que tiene mi base de datos
    $.ajax({
        url: 'api/readUser.php',
        type: 'GET',
        dataType: 'json',
        success: function(response){
            response['body'].forEach(p => {

                const id = p.id

                let item = `
                <li>
                <h5 class="p-3">Lista de Usuarios</h5>
                <div class="p-1"></div>
				<div class="p-1">Nombre: <input type="text" value="${p.nombre}" id="nombre${p.id}" /></div>
                <div class="p-1">Apellidos: <input type="text" value="${p.apellidos}" id="apellidos${p.id}"/></div>
                <div class="p-1">Email: <input type="text" value="${p.email}" id="email${p.id}"/></div>
                <div class="p-1">Usuario: <input type="text" value="${p.usuario}" id="usuario${p.id}"/></div>
                <div class="p-1">Contraseña: <input type="password" value="${p.contrasena}" id="contrasena${p.id}"/></div>
				<br>
                <button class="btn-success"id="editar${p.id}">Editar Usuario</button>
                <button class="btn-danger"id="eliminar${p.id}">Eliminar Usuario</button>
                <hr>
			    </li>
                `
                $('#personas').append(item)

                $('#eliminar' + id).click( () => {
                    $.ajax({
                        url: 'api/deleteUser.php',
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            id: id
                        },
                        success: function (response) {
                            console.log("Usuario Eliminado")
                        }
                    })
                })

                $('#editar' + id).click( () => {
                    const editar_nombre = $('#nombre' + id).val();
                    const editar_apellidos = $('#apellidos' + id).val();
                    const editar_email = $('#email' + id).val();
                    const editar_usuario = $('#usuario' + id).val();
                    const editar_contrasena = $('#contrasena' + id).val();

                    $.ajax({
                        url: 'api/updateUser.php',
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            id: id,
                            nombre: editar_nombre,
                            apellidos: editar_apellidos,
                            email: editar_email,
                            usuario: editar_usuario,
                            contrasena: editar_contrasena
                        },
                        success: function (response) {
                            console.log("Producto editado")
                        }, error: function (xhr) {
                            console.log(xhr.responseText)
                        }
                    })
                })




           });
           
        }
    });
  }