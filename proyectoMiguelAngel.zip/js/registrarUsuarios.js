$(document).ready( () => {

    $('#create').click( () => {
        crearUsuario();
    })


})



function crearUsuario() {
    const nombre = $('#nombre').val();
    const apellidos = $('#apellidos').val();
    const usuario = $('#usuario').val();
    const contrasena = $('#contrasena').val();
    const email = $('#email').val();


    $.ajax({
        url: 'api/createUser.php',
        dataType: 'json',
        type: 'POST',
        data: {
            nombre: nombre,
            apellidos: apellidos,
            usuario: usuario,
            contrasena: contrasena,
            email: email
        }, success: function (respuesta) {
            console.log("Se ha añadido el Usuario correctamente")
        }, error: function (xhr) {
            console.log("Error al añadir Usuario")
        }, complete: function () {
            console.log("completado")
        }
    })

    

    
}

const nombre = document.getElementById('nombre');
const apellido = document.getElementById('apellidos')
const email = document.getElementById('email')
const password = document.getElementById('password')
const usuario = document.getElementById('usuario')
const registro = document.getElementById('formulario')


const expresionesRegulares ={
nombre: /^[a-zA-ZáÁ-Ÿ\s]{2,40}$/,
user: /^[a-zA-Z0-9\_\-]{4,20}$/,//letras mayusculas minusculas, numeros del 0 al 9, _ y - con un minimo de 6 y un maximo de 20
correo: /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/,
passw: /^[a-zA-Z0-9\_\-]{4,30}$/ // tiene que contener una mayúscula, una minúscula y 1 numero minimo tambien puede contener carácteres especiales
}

const camposRegistro = {
	usuario: false,
	password: false,
	nombre: false,
	apellido: false,
	email:false
}
document.getElementById('errorN').style.display="none";
document.getElementById('errorA').style.display="none";
document.getElementById('errorE').style.display="none";
document.getElementById('errorU').style.display="none";
document.getElementById('errorP').style.display="none";
document.getElementById('correcto').style.display="none";
document.getElementById('incorrecto').style.display="none";




function validarNombre(){
    if (expresionesRegulares.nombre.test(nombre.value)){
        document.getElementById('errorN').style.display="none";  //Si está bien la expresion regular no me sale el mensaje de error
        camposRegistro.nombre = true;
    } else{
        document.getElementById('errorN').style.display="block"; //Si no está bien pues sale el mensaje de error
        document.getElementById('errorN').style.color="red";    
        camposRegistro.nombre = false;
    }
}

function validarApellido(){
    if(expresionesRegulares.nombre.test(apellido.value)){
        document.getElementById('errorA').style.display="none";
        camposRegistro.apellido = true;
    } else{
        document.getElementById('errorA').style.display="block";
        document.getElementById('errorA').style.color="red";    
        camposRegistro.apellido = false;
    }
}

function validarCorreo(){
    if(expresionesRegulares.correo.test(email.value)){
        document.getElementById('errorE').style.display="none";
        camposRegistro.email = true;
    } else{
        document.getElementById('errorE').style.display="block";
        document.getElementById('errorE').style.color="red";   
        camposRegistro.email = false;
 
    }
}

function validarUsuario(){
    if(expresionesRegulares.user.test(usuario.value)){
        document.getElementById('errorU').style.display="none";
        camposRegistro.usuario = true;
    } else{
        document.getElementById('errorU').style.display="block";
        document.getElementById('errorU').style.color="red";    
        camposRegistro.usuario = false;
    }
}

function validarPassword(){
    if(expresionesRegulares.passw.test(password.value)){
        document.getElementById('errorP').style.display="none";
        camposRegistro.password = true;
    } else{
        document.getElementById('errorP').style.display="block";
        document.getElementById('errorP').style.color="red";    
        camposRegistro.password = false;
    }
    console.log(camposRegistro.password);
}

registro.addEventListener('submit', (e) => {
	
	if(camposRegistro.nombre && camposRegistro.apellido && camposRegistro.email && camposRegistro.usuario && camposRegistro.password){
        document.getElementById('correcto').style.display="block";
        document.getElementById('correcto').style.color="green";
		setTimeout(() => {
			document.getElementById('correcto').style.display="none";
		}, 5000);
	} else {
		e.preventDefault();
		document.getElementById('incorrecto').style.display="block";
        document.getElementById('incorrecto').style.color="red";
		setTimeout(() => {
			document.getElementById('incorrecto').style.display="none";
		}, 5000);
	}
});

nombre.addEventListener('blur', validarNombre);
apellido.addEventListener('blur', validarApellido);
email.addEventListener('blur', validarCorreo);
usuario.addEventListener('blur', validarUsuario);
password.addEventListener('blur', validarPassword);

