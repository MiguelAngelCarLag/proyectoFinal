$(document).ready(() => {

    $.ajax({
        url: 'api/read.php',
        type: 'GET',
        dataType: 'json',
        success: function (response) {
            const productos = response['body']

            productos.forEach(producto => {

                let item = `
                    <div class="">
                        <div class="">
                            <div class="card">
                                <img class="card-img-top" src="images/manga-${producto.id}.jpeg" alt="Card image cap">
                                <div class="card-body">
                                <h5 class="card-title">${producto.nombre_producto}</h5>
                                <p class="card-text">${producto.descripcion}</p>
                                <p class="card-text">${producto.precio} euros.</p>
                                <a href="#" class="btn btn-primary">Comprar</a>
                                </div>
                            </div>
                        </div>
                    </div>  
                  
                 
        `;

                $('#dinamico').append(item);

            });

        }
    })




})