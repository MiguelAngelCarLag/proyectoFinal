<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="estilos/custom.css">
    <script src="js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-orange">
        <div class="container-fluid">
            <a class="navbar-brand" href="images/logoFinal.PNG"><img src="images/logoFinal.PNG" width="60px"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 nav-pills">
                <li class="nav-item">
                <a class="nav-link text-dark" aria-current="page" href="index.php">Inicio</a>
                </li>
                <li class="nav-item">
                <a class="nav-link text-dark" href="catalogo.php">Catálogo</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="iniciarSesion.php">Iniciar Sesión</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark active bg-warning" type="hidden" href="registro.php">Registrarse</a>
                </li>
                </ul>
            </div>          
      </div>
  </nav>
  <div class="container">
    <div class="row">
        <div class="col">
            <div class="shadow-lg bg-light p-3 mb-5 mt-4 rounded">
            <form class="row g-3" id="formulario" action="">
                <div class="col-md-12 border-primary">                   
                              <div align="center">
                                    <h3>Registro de Usuarios</h3>
                                    </div>
                                        <hr>
                                        <ul id="lista_crear">
                                            <li>
                                                <div>Nombre: <input type="text" value="" id="nombre"/><p id="errorN">No acepta caracteres alfanuméricos ni el campo puede estar en blanco</p></div>                                         
                                                <div>Apellidos: <input type="text" value="" size="" id="apellidos"/><p id="errorA">No acepta caracteres alfanuméricos ni el campo puede estar en blanco</p></div>
                                                <div>Usuario : <input type="text" value="" size="" id="usuario"><p id="errorU">Usuario mal introducido</p></div>
                                                <div>contrasena : <input type="text" value="" size="" id="contrasena"><p id="errorP">Contraseña mal introducida</p></div>
                                                <div>Email : <input type="text" value="" size="" id="email"><p id="errorE">Email mal introducido ejemplo johndoe@gmail.com</p></div>
                                                <br>
                                                <button id="create" class="btn btn-primary">Registrar nuevo usuario</button>		
                                            </li>
                                        </ul>
                                </div>
                    </div>
            </form>    
</body>
<script src="js/jquery_3.js"></script>
<script src="js/registrarUsuarios.js"></script>
</html>