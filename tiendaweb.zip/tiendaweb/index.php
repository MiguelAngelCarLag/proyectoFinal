<link rel="stylesheet" href="./css/darklybootstrap.css" />
                
        <div class="jumbotron text-center">
                    <br><br><br>
                    <h1 class="display-2"><strong>Licores El Chuzo</strong></h1>
                    <p class="lead">Asúmelo, sin beber no eres feliz... este es tu sitio</p>
                    
                    <div class="col">
                    <div align="center">
                    <img src="img/chuzo.jpg" width="250" alt="600">
                    
                    </div>
	                 <br>   
                    <p>Solo para mayores de 18 años...</p>
                    <p class="lead">
                        <a class="btn btn-warning btn-lg" href="https://plazasesamo.com/juegos/" role="button">Si eres menor de edad pulsa aqui</a>
                        <a class="btn btn-success btn-lg" href="index1.php" role="button">Soy mayor de edad...</a>
                    </p>
        </div>





      