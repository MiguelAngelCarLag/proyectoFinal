<?php include("template/cabecera2.php"); ?>

<?php 
include("administrador/config/bd.php");
$sentenciaSQL=$conexion->prepare("SELECT * FROM whisky");
$sentenciaSQL->execute();
$listaproductos=$sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);
?>

<?php foreach($listaproductos as $whisky){ ?>
<div class="col-md-2">
<div class="card">
<img class="card-img-top" src="./img/<?php echo $whisky['imagen']; ?>" alt="">
<div class="card-body">
    <h5 class="card-title"><?php echo $whisky['nombre']; ?></h5>
    <h6 class="card-title"><?php echo $whisky['precio']; ?>€</h6>
    <a name="" id="" class="btn btn-primary" href="paypal.php" role="button"> Comprar </a>
</div>
</div>
</div>
<?php }?>

<?php include("template/pie.php"); ?>