<!DOCTYPE html
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Licores Carmona</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/darklybootstrap.css" />
    <link href="/css/estilos.css" rel="stylesheet">
</head>

<body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary" gap="10%">
            <ul class="nav navbar-nav">
                <a class="navbar-brand"><strong>Licores Carmona</strong></a> </strong>
                <button class="navbar-toggler" data-target="#my-nav" data-toggle="collapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <li class="nav-item">
                    <a class="nav-link" href="index1.php"><strong>Inicio</strong></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="productos1.php"><strong>Cerveza</strong></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="productos2.php"><strong>Ginebra</strong></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="productos3.php"><strong>Ron</strong></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="productos4.php"><strong>Vino</strong></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="productos5.php"><strong>Vodka</strong></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="productos6.php"><strong>Whisky</strong></a>
                </li>   
                <li class="nav-item">
                    <a class="nav-link" href="nosotros.php">Sobre nosotros...</a>
                </li>
                <li class="nav-item active">
                    <a class="btn btn-warning" href="mostrarcarrito.php">Carrito(<?php
                    echo(empty($_SESSION['CARRITO']))?0:count($_SESSION['CARRITO']);
                    ?>)</a>
                </li>                           
                <li>
                <a href="https://www.google.es/" class="btn btn-success">Salir a Google</a>
                </li>
            </ul>
        </nav>
        <br><br>
        <div class="container">
            <div class="row">