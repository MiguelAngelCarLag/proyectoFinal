</div>

<div class="container">
            <div class="row">
    
    <nav class="navbar navbar-expand lg navbar-dark bg-primary">
            
            <ul class="nav navbar-nav">
               
             
                <li class="nav-item">
                    <a class="btn btn-warning" href="./miguel.php"><strong>Proyecto fin de Grado de Miguel Angel Carmona Lago: </strong></a>
                </li>
                <li class="nav-item">
                </li>
             
            </ul>
    
    </nav>
      


</body>
</html>


        