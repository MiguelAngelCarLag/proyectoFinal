<?php include('template/cabecera.php') ?>


        <div class="col-md-12">
            <div class="jumbotron">
                
                    <h1 class="display-3">Bienvenido <?php echo $nombrUsuario;?></h1>
                    <p class="lead">Este es el administrador de la tienda</p>
                    <p>Aqui se hacen las anotaciones de tareas pendientes</p>
                    <p></p>
                    <input size="100" type="save" name="tipo_de_dato"/><br><br>
                    <input size="100" type="text" name="tipo_de_dato"/><br><br>
                    <input size="100" type="text" name="tipo_de_dato"/><br><br>
                    <input size="100" type="save" name="tipo_de_dato"/><br><br>
                    <input size="100" type="save" name="tipo_de_dato"/><br><br>
                    <hr class="my-2">

                    <div class="btn-group" role="group" aria-label="">
                        <button type="submit" name="accion"  value="Guardar" class="btn btn-success">Guardar cambios</button>                      
                    </div>
            </div>
        </div>
             
