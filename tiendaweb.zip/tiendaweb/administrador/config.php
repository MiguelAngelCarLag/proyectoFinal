<?php
define("KEY","carmona");
define("COD","AES-128-ECB");
?>