<?php include("template/cabecera2.php"); ?>

<?php 
include("administrador/config/bd.php");
$sentenciaSQL=$conexion->prepare("SELECT * FROM vodka");
$sentenciaSQL->execute();
$listaproductos=$sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);
?>

<?php foreach($listaproductos as $vodka){ ?>
<div class="col-md-2">
    <div class="card">
    <img class="card-img-top" src="./img/<?php echo $vodka['imagen']; ?>" alt="">
        <div class="card-body">
        <h5 class="card-title"><?php echo $vodka['nombre']; ?></h5>
        <h6 class="card-title"><?php echo $vodka['precio']; ?>€</h6>
            <div class="d-grid gap3-3 col-6 mx-auto">
                <button class="btn btn-primary" role="button"> Comprar </a>
            </div>
        </div>
    </div>
</div>
<?php }?>

